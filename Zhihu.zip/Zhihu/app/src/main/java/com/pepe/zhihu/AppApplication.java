package com.pepe.zhihu;

import android.app.Application;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Build;

import com.pepe.zhihu.inject.component.AppComponent;
import com.pepe.zhihu.inject.module.AppModule;

/**
 * @author 1one
 * @date 2019/8/24.
 */
public class AppApplication extends Application {

    private static AppApplication application;
    private AppComponent mAppComponent;

    @Override
    public void onCreate() {
        super.onCreate();
        application = this;
        mAppComponent = DaggerAppComponent.builder()
                .appModule(new AppModule(this))
                .build();
        initNetwork();
    }

    private void initNetwork(){
//        NetBroadcastReceiver receiver = new NetBroadcastReceiver();
//        IntentFilter filter;
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//            filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
//        } else {
//            filter = new IntentFilter();
//            filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
//        }
//        registerReceiver(receiver, filter);
//
//        NetHelper.INSTANCE.init(this);
    }

    public static AppApplication get(){
        return application;
    }

    public AppComponent getAppComponent(){
        return mAppComponent;
    }
}
