package com.pepe.zhihu.ui.fragment.base;

import androidx.fragment.app.Fragment;

/**
 * @author 1one
 * @date 2019/8/24.
 */
public class BaseFragment extends Fragment {
}
